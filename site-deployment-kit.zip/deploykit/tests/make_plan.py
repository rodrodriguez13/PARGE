"""Genera un AP Plan de prueba (2 plantas, 3 colores, leyenda) en vectorial, rasterizado y rotado."""
import sys, random
import pymupdf as fitz

RED, BLUE, GREEN = (0.88, 0.19, 0.19), (0.13, 0.4, 0.85), (0.1, 0.65, 0.3)


def build(path, raster=False, rotate=0, seed=1):
    random.seed(seed)
    doc = fitz.open()
    plan = {0: {RED: 6, BLUE: 4, GREEN: 1}, 1: {RED: 6, BLUE: 3, GREEN: 1}}
    for floor in (0, 1):
        pg = doc.new_page(width=1190, height=842)
        pg.insert_text((40, 40), f"LEVEL {floor+1} - FLOOR PLAN", fontsize=18)
        rooms = []
        for i in range(8):
            x0 = 60 + i * 130; rooms.append((x0, 100, x0 + 120, 260, f"{floor+1}{i+1:02d}"))
            rooms.append((x0, 420, x0 + 120, 580, f"{floor+1}{i+9:02d}"))
        for (x0, y0, x1, y1, n) in rooms:
            pg.draw_rect(fitz.Rect(x0, y0, x1, y1), color=(0.2, 0.2, 0.2), width=1.2)
            pg.insert_text((x0 + 45, y1 - 12), n, fontsize=11)
        pg.draw_rect(fitz.Rect(60, 270, 1100, 410), color=(0.6, 0.6, 0.6), fill=(0.93, 0.93, 0.93), width=0.5)
        spots = [(r[0] + 60, r[3] - 40) for r in rooms]
        random.shuffle(spots)
        k = 0
        for col, n in plan[floor].items():
            for _ in range(n):
                cx, cy = spots[k]; k += 1
                pg.draw_circle((cx, cy), 7, color=(0, 0, 0), fill=col, width=0.6)
        # leyenda (no son APs reales)
        for j, (col, name) in enumerate(((RED, "CW9172H"), (BLUE, "CW9164I"), (GREEN, "CW9176I"))):
            pg.draw_circle((900, 700 + j * 30), 7, color=(0, 0, 0), fill=col, width=0.6)
            pg.insert_text((915, 704 + j * 30), name, fontsize=11)
    if rotate:
        for pg in doc: pg.set_rotation(rotate)
    if raster:
        out = fitz.open()
        for pg in doc:
            pix = pg.get_pixmap(dpi=150)
            np_ = out.new_page(width=pg.rect.width, height=pg.rect.height)
            np_.insert_image(np_.rect, pixmap=pix)
        doc = out
    doc.save(path)


if __name__ == "__main__":
    build("tests/plan_vector.pdf"); build("tests/plan_raster.pdf", raster=True); build("tests/plan_rot.pdf", rotate=90)
    print("ok")
