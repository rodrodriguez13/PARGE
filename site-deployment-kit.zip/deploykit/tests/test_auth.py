"""Código de acceso compartido."""
import os, sys, tempfile
os.environ["DATA_DIR"] = tempfile.mkdtemp(); os.environ["ACCESS_CODE"] = "parge-2026"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fastapi.testclient import TestClient
from app.main import app

with TestClient(app) as c:
    assert c.get("/api/projects").status_code == 401                          # sin código
    assert c.get("/api/config").json() == {"auth": True, "logged_in": False, "team": ["Héctor", "César", "Luis", "Rubén", "Otto"]}
    assert c.get("/").status_code == 200                                      # la página carga y pide el código
    assert c.post("/api/login", json={"code": "mal"}).status_code == 401
    assert c.post("/api/login", json={"code": "parge-2026"}).status_code == 200
    assert c.get("/api/config").json()["logged_in"] is True
    pid = c.get("/api/projects").json()[0]["id"]                              # ya con sesión (cookie)
    d = c.post(f"/api/projects/{pid}/devices", json={"model": "CW9172H", "box_code": "AP01"}).json()
    r = c.patch(f"/api/devices/{d['id']}", json={"installed": True}, headers={"X-User-Name": "H%C3%A9ctor"}).json()
    assert r["installed"] and r["installed_by"] == "Héctor"
    assert c.get(f"/api/projects/{pid}/portmap.xlsx").status_code == 200      # descargas e imágenes usan la cookie
    c.post("/api/logout"); assert c.get("/api/projects").status_code == 401
    for _ in range(12): c.post("/api/login", json={"code": "x"})
    assert c.post("/api/login", json={"code": "parge-2026"}).status_code == 429   # freno a adivinar el código
print("AUTH OK")
