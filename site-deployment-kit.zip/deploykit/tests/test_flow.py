import os, sys, tempfile, io
os.environ["DATA_DIR"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fastapi.testclient import TestClient
from app import vision
from app.main import app

PORTO = "/mnt/user-data/uploads/0a30d379-HST-OPOPD_Provisioning_File_13-05-2026_1.xlsx"
HERE = os.path.dirname(os.path.abspath(__file__))

with TestClient(app) as c:
    projs = c.get("/api/projects").json()
    assert projs[0]["inn_code"] == "PARGE", projs
    pid = projs[0]["id"]

    # --- Módulo 1a: plantilla precargada (archivo real de Porto en un proyecto aparte)
    p2 = c.post("/api/projects", json={"name": "Porto test", "chain": "Hilton", "inn_code": "OPOPD"}).json()
    r = c.post(f"/api/projects/{p2['id']}/inventory/import", files={"file": ("p.xlsx", open(PORTO, "rb"))}).json()
    print("import:", r)
    assert r["added"] == 70

    # --- Módulo 1b: escaneo con proveedor simulado + validación
    def fake(images, hints):
        return [
            {"box_code": "AP01", "model": "MR36H", "mac": "e4:55:a8:e1:10:99", "serial": "Q3NB-ZR7N-2FYK", "confidence": .95},   # coincide
            {"box_code": "AP02", "model": "MR46",  "mac": "e4:55:a8:e0:fd:fc", "serial": "Q3NB-ZZ3L-T5CH", "confidence": .9},    # modelo distinto (esperado MR36H)
            {"box_code": "AP03", "model": "CW9172H", "mac": "aa:bb:cc:00:11:22", "serial": "Q9XX-AAAA-BBBB", "confidence": .9},   # nuevo
            {"box_code": "SW01", "model": "C9300-48U-M-HILU", "mac": "08:0f:e5:28:5c:80", "serial": "FJC29301L9A", "confidence": .9},
        ]
    vision.PROVIDER_OVERRIDE = fake
    sc = c.post(f"/api/projects/{p2['id']}/scan", files=[("files", ("a.jpg", b"x", "image/jpeg"))]).json()
    print("match preview:", [(i["box_code"], i["match"], i["flags"]) for i in sc["items"]])
    res = c.post(f"/api/projects/{p2['id']}/scan/commit", json={"items": sc["items"], "scan_id": sc["scan_id"]}).json()
    print("commit:", res)
    assert res["confirmed"] == 2 and res["mismatch"] == 1 and res["added"] == 1
    # re-escanear el mismo lote no debe duplicar
    res2 = c.post(f"/api/projects/{p2['id']}/scan/commit", json={"items": sc["items"]}).json()
    assert res2["duplicates"] >= 3, res2
    names = {d["box_code"]: d for d in c.get(f"/api/projects/{p2['id']}/devices").json() if d["box_code"]}
    print("SW01 name:", names["SW01"]["name"], "| issues AP02:", names["AP02"]["issues"])

    # --- Módulo 2a: racks + ubicación
    racks = c.put(f"/api/projects/{pid}/racks", json=[
        {"code": "MDF", "rtype": "MDF", "location": "Sótano - cuarto técnico", "floor": "-1", "units": 42},
        {"code": "IDF01", "rtype": "IDF", "location": "Planta 1", "floor": "1", "units": 24}]).json()
    # --- inventario PARGE manual: 12 + 7 + 2 APs y 2 switches, 1 MX
    n = 0
    def add(model, code, **kw):
        return c.post(f"/api/projects/{pid}/devices", json={"model": model, "box_code": code, **kw}).json()
    for model, cnt in (("CW9172H", 12), ("CW9164I", 7), ("CW9176I", 2)):
        for _ in range(cnt):
            n += 1; add(model, f"AP{n:02d}", serial=f"Q9AA-{n:04d}-ZZZZ"[:14])
    sw1 = add("C9300-48U", "SW03"); mx = add("MX105", "MX01")
    assert sw1["name"] == "HLT-PARGE-9300-?-AS03", sw1["name"]
    r = c.put(f"/api/projects/{pid}/placements", json=[
        {"id": sw1["id"], "rack_id": racks[0]["id"], "rack_u": 10, "rack_h": 1},
        {"id": mx["id"], "rack_id": racks[0]["id"], "rack_u": 10, "rack_h": 1}]).json()
    print("placement warnings:", r)
    assert r["warnings"], "debería avisar del solape en U10"
    c.put(f"/api/projects/{pid}/placements", json=[{"id": mx["id"], "rack_id": racks[0]["id"], "rack_u": 12, "rack_h": 1}])
    devs = {d["id"]: d for d in c.get(f"/api/projects/{pid}/devices").json()}
    print("SW name:", devs[sw1["id"]]["name"], "| MX name:", devs[mx["id"]]["name"])
    assert devs[sw1["id"]]["name"] == "HLT-PARGE-9300-MDF-AS03"

    # --- Módulo 2b: AP plan
    for fname in ("plan_vector.pdf", "plan_raster.pdf"):
        st = c.post(f"/api/projects/{pid}/applan", files={"file": (fname, open(os.path.join(HERE, fname), "rb"), "application/pdf")}).json()
        print(fname, st["plan"]["mode"], "colores:", [(g["color"], g["count"], g["model"]) for g in st["colors"]])
        if st["plan"]["mode"] == "raster":      # sin capa de texto no se detecta la leyenda: el usuario la ignora a mano
            for m in [m for m in st["markers"] if m["x"] > 880 and m["y"] > 680]:
                st = c.patch(f"/api/ap-markers/{m['id']}", json={"ignored": True}).json()
            st = c.put(f"/api/applan/{st['plan']['id']}", json={"color_map": {g["color"]: mod for g, mod in zip(st["colors"], ("CW9172H", "CW9164I", "CW9176I"))}}).json()
            print("  tras ignorar leyenda:", [(g["color"], g["count"], g["model"]) for g in st["colors"]])
        assert len(st["plan"]["color_map"]) == 3, "debería mapear por cantidades únicas (12/7/2)"
        out = c.post(f"/api/applan/{st['plan']['id']}/assign").json()
        print("  asignación:", [(r["model"], r["positions"], r["boxes"], r["assigned"]) for r in out["report"]])
        assert all(r["assigned"] == r["positions"] == r["boxes"] for r in out["report"])
    devs = c.get(f"/api/projects/{pid}/devices").json()
    aps = [d for d in devs if d["dtype"] == "AP"]
    print("ejemplo AP:", aps[0]["name"], "|", aps[-1]["name"])
    assert all(d["floor"] for d in aps)
    pdf = c.get(f"/api/applan/{st['plan']['id']}/annotated.pdf")
    open(os.path.join(HERE, "out_annotated_raster.pdf"), "wb").write(pdf.content)
    st = c.post(f"/api/projects/{pid}/applan", files={"file": ("v.pdf", open(os.path.join(HERE, "plan_vector.pdf"), "rb"), "application/pdf")}).json()
    c.post(f"/api/applan/{st['plan']['id']}/assign")
    pdf = c.get(f"/api/applan/{st['plan']['id']}/annotated.pdf")
    open(os.path.join(HERE, "out_annotated_vector.pdf"), "wb").write(pdf.content)
    print("PDF anotado:", len(pdf.content), "bytes, sin asignar:", pdf.headers["X-Unassigned"])
    x = c.get(f"/api/projects/{pid}/export.xlsx"); assert x.status_code == 200 and len(x.content) > 3000
    print("export xlsx:", len(x.content)); print(c.get(f"/api/projects/{pid}/export.csv").text[:300])
print("TODO OK")
