"""Módulo 3: racks MDF/IDF, puertos de switch, instalado y foto (sitio PARGE). Requiere el Hardware Order real."""
import os, sys, io, glob, tempfile
os.environ["DATA_DIR"] = tempfile.mkdtemp(); sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fastapi.testclient import TestClient
from PIL import Image
from app.main import app

f = os.path.join(os.path.dirname(__file__), "PARGE_Hardware_Order.xlsx")
with TestClient(app) as c:
    pid = c.get("/api/projects").json()[0]["id"]
    c.post(f"/api/projects/{pid}/inventory/import", files={"file": ("o.xlsx", open(f, "rb"))})
    c.post(f"/api/projects/{pid}/numbering", json={"dtype": "AP", "order": ["CW9174I-CFG-HILU", "CW9172I-CFG-HILU", "CW9172H-RTG-HILU"],
                                                   "spares": {"CW9172I-CFG-HILU": 1, "CW9172H-RTG-HILU": 1}})
    pm = c.get(f"/api/projects/{pid}/portmap").json()
    sw = {s["box_code"]: s for s in pm["switches"]}
    assert [sw[k]["rack"] for k in ("SW01", "SW02", "SW03", "SW04")] == ["MDF", "MDF", "IDF", "IDF"]
    used = lambda s: [(p["port"], p["box_code"]) for p in s["ports"] if "device_id" in p]
    assert used(sw["SW01"]) == [] and used(sw["SW04"]) == []
    assert used(sw["SW02"]) == [(i, f"AP{i:02d}") for i in range(1, 18)]          # pasillos: AP01-AP17 en puertos 1-17
    assert used(sw["SW03"]) == [(i, f"AP{i + 18:02d}") for i in range(1, 34)]     # habitaciones: AP19-AP51 en puertos 1-33
    ds = c.get(f"/api/projects/{pid}/devices").json()
    assert all(d["sw_port"] is None for d in ds if d["spare"])
    ap20 = next(d for d in ds if d["box_code"] == "AP20")
    assert c.patch(f"/api/devices/{ap20['id']}", json={"sw_port": 1}).status_code == 400   # puerto ocupado
    assert c.patch(f"/api/devices/{ap20['id']}", json={"installed": True}).json()["installed"]
    b = io.BytesIO(); Image.new("RGB", (3000, 2000), "red").save(b, "JPEG"); b.seek(0)
    assert c.post(f"/api/devices/{ap20['id']}/photo", files={"file": ("a.jpg", b, "image/jpeg")}).json()["has_photo"]
    assert c.get(f"/api/devices/{ap20['id']}/photo?w=300").status_code == 200
    c.post(f"/api/projects/{pid}/site-plan")                                              # idempotente
    assert used({"ports": c.get(f"/api/projects/{pid}/portmap").json()["switches"][2]["ports"]})[1] == (2, "AP20")
    assert len(c.get(f"/api/projects/{pid}/portmap.xlsx").content) > 3000
print("MODULO 3 OK")
